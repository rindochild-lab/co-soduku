// Co-Sudoku Prototype 0.1
// Local single-device Sudoku engine.
// Multiplayer synchronization will be added in the next milestone.

const boardElement = document.getElementById("board");
const numberPad = document.getElementById("numberPad");
const selectedCellLabel = document.getElementById("selectedCell");
const messageElement = document.getElementById("message");
const timerElement = document.getElementById("timer");
const newGameButton = document.getElementById("newGame");
const checkGameButton = document.getElementById("checkGame");

let solution = [];
let puzzle = [];
let currentBoard = [];
let selectedIndex = null;
let seconds = 0;
let timerId = null;

// A few seeds keep the prototype predictable while we develop the UI.
const PUZZLES = [
  [
    "530070000",
    "600195000",
    "098000060",
    "800060003",
    "400803001",
    "700020006",
    "060000280",
    "000419005",
    "000080079"
  ],
  [
    "003020600",
    "900305001",
    "001806400",
    "008102900",
    "700000008",
    "006708200",
    "002609500",
    "800203009",
    "005010300"
  ],
  [
    "200080300",
    "060070084",
    "030500209",
    "000105408",
    "000000000",
    "402706000",
    "301007040",
    "720040060",
    "004010003"
  ]
];

function parsePuzzle(rows) {
  return rows.map(row => [...row].map(Number));
}

function cloneGrid(grid) {
  return grid.map(row => [...row]);
}

function generateFullSolution() {
  // Generate a valid Sudoku solution using backtracking.
  const grid = Array.from({ length: 9 }, () => Array(9).fill(0));

  function isSafe(row, col, num) {
    for (let i = 0; i < 9; i++) {
      if (grid[row][i] === num || grid[i][col] === num) return false;
    }

    const startRow = Math.floor(row / 3) * 3;
    const startCol = Math.floor(col / 3) * 3;

    for (let r = startRow; r < startRow + 3; r++) {
      for (let c = startCol; c < startCol + 3; c++) {
        if (grid[r][c] === num) return false;
      }
    }

    return true;
  }

  function fill(position = 0) {
    if (position === 81) return true;

    const row = Math.floor(position / 9);
    const col = position % 9;
    const nums = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);

    for (const num of nums) {
      if (isSafe(row, col, num)) {
        grid[row][col] = num;
        if (fill(position + 1)) return true;
        grid[row][col] = 0;
      }
    }

    return false;
  }

  fill();
  return grid;
}

function shuffle(array) {
  const result = [...array];

  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }

  return result;
}

function createPuzzleFromSolution(fullSolution, blanks = 48) {
  const result = cloneGrid(fullSolution);
  const positions = shuffle([...Array(81).keys()]);

  for (let i = 0; i < blanks; i++) {
    const position = positions[i];
    result[Math.floor(position / 9)][position % 9] = 0;
  }

  return result;
}

function newGame() {
  // Use a curated puzzle about 70% of the time so the prototype feels consistent.
  // Otherwise generate a fresh valid solution and remove cells.
  if (Math.random() < 0.7) {
    puzzle = parsePuzzle(PUZZLES[Math.floor(Math.random() * PUZZLES.length)]);
    solution = solveGrid(cloneGrid(puzzle));

    if (!solution) {
      solution = generateFullSolution();
    }
  } else {
    solution = generateFullSolution();
    puzzle = createPuzzleFromSolution(solution, 48);
  }

  currentBoard = cloneGrid(puzzle);
  selectedIndex = null;
  seconds = 0;

  startTimer();
  renderBoard();
  updateSelectedLabel();
  setMessage("Choose a square, then enter a number.");
}

function solveGrid(grid) {
  function findEmpty() {
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        if (grid[r][c] === 0) return [r, c];
      }
    }
    return null;
  }

  function isSafe(row, col, num) {
    for (let i = 0; i < 9; i++) {
      if (grid[row][i] === num || grid[i][col] === num) return false;
    }

    const sr = Math.floor(row / 3) * 3;
    const sc = Math.floor(col / 3) * 3;

    for (let r = sr; r < sr + 3; r++) {
      for (let c = sc; c < sc + 3; c++) {
        if (grid[r][c] === num) return false;
      }
    }

    return true;
  }

  function solve() {
    const empty = findEmpty();
    if (!empty) return true;

    const [row, col] = empty;

    for (let num = 1; num <= 9; num++) {
      if (isSafe(row, col, num)) {
        grid[row][col] = num;
        if (solve()) return true;
        grid[row][col] = 0;
      }
    }

    return false;
  }

  return solve() ? grid : null;
}

function renderBoard() {
  boardElement.innerHTML = "";

  for (let index = 0; index < 81; index++) {
    const row = Math.floor(index / 9);
    const col = index % 9;
    const cell = document.createElement("button");

    cell.className = "cell";
    cell.type = "button";
    cell.dataset.index = index;
    cell.setAttribute("aria-label", `Row ${row + 1}, Column ${col + 1}`);

    const value = currentBoard[row][col];

    if (puzzle[row][col] !== 0) {
      cell.classList.add("given");
    } else if (value !== 0) {
      cell.classList.add("user");
    }

    if (selectedIndex === index) {
      cell.classList.add("selected");
    }

    if (selectedIndex !== null) {
      const selectedRow = Math.floor(selectedIndex / 9);
      const selectedCol = selectedIndex % 9;

      if (row === selectedRow || col === selectedCol ||
          (Math.floor(row / 3) === Math.floor(selectedRow / 3) &&
           Math.floor(col / 3) === Math.floor(selectedCol / 3))) {
        cell.classList.add("related");
      }
    }

    if (value !== 0) {
      cell.textContent = value;
    }

    cell.addEventListener("click", () => selectCell(index));
    boardElement.appendChild(cell);
  }

  markConflicts();
}

function selectCell(index) {
  const row = Math.floor(index / 9);
  const col = index % 9;

  if (puzzle[row][col] !== 0) {
    selectedIndex = index;
    setMessage("That number is part of the original puzzle.");
  } else {
    selectedIndex = index;
    setMessage("Enter a number for this square.");
  }

  renderBoard();
  updateSelectedLabel();
}

function updateSelectedLabel() {
  if (selectedIndex === null) {
    selectedCellLabel.textContent = "—";
    return;
  }

  const row = Math.floor(selectedIndex / 9) + 1;
  const col = selectedIndex % 9 + 1;
  selectedCellLabel.textContent = `R${row} C${col}`;
}

function enterNumber(number) {
  if (selectedIndex === null) {
    setMessage("Select a square first.");
    return;
  }

  const row = Math.floor(selectedIndex / 9);
  const col = selectedIndex % 9;

  if (puzzle[row][col] !== 0) {
    setMessage("Original puzzle numbers can't be changed.");
    return;
  }

  currentBoard[row][col] = number;
  markConflicts();
  renderBoard();
  checkForCompletion();
}

function markConflicts() {
  const cells = [...boardElement.querySelectorAll(".cell")];

  for (let index = 0; index < 81; index++) {
    const row = Math.floor(index / 9);
    const col = index % 9;
    const value = currentBoard[row][col];

    if (value === 0) continue;

    let conflict = false;

    for (let c = 0; c < 9; c++) {
      if (c !== col && currentBoard[row][c] === value) conflict = true;
    }

    for (let r = 0; r < 9; r++) {
      if (r !== row && currentBoard[r][col] === value) conflict = true;
    }

    const sr = Math.floor(row / 3) * 3;
    const sc = Math.floor(col / 3) * 3;

    for (let r = sr; r < sr + 3; r++) {
      for (let c = sc; c < sc + 3; c++) {
        if ((r !== row || c !== col) && currentBoard[r][c] === value) {
          conflict = true;
        }
      }
    }

    if (conflict) {
      cells[index]?.classList.add("conflict");
    }
  }
}

function checkForCompletion() {
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      if (currentBoard[r][c] !== solution[r][c]) return false;
    }
  }

  stopTimer();
  setMessage(`Solved together in ${formatTime(seconds)}!`, "success");

  document.querySelectorAll(".cell").forEach(cell => {
    cell.classList.add("correct");
  });

  return true;
}

function checkPuzzle() {
  let incorrect = 0;
  let empty = 0;

  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      const value = currentBoard[r][c];

      if (value === 0) {
        empty++;
      } else if (value !== solution[r][c]) {
        incorrect++;
      }
    }
  }

  if (incorrect === 0 && empty === 0) {
    checkForCompletion();
  } else if (incorrect > 0) {
    setMessage(`${incorrect} number${incorrect === 1 ? "" : "s"} need another look.`, "error");
  } else {
    setMessage(`${empty} square${empty === 1 ? "" : "s"} still empty.`);
  }

  renderBoard();
}

function setMessage(text, type = "") {
  messageElement.textContent = text;
  messageElement.className = "message";
  if (type) messageElement.classList.add(type);
}

function startTimer() {
  stopTimer();
  updateTimer();

  timerId = setInterval(() => {
    seconds++;
    updateTimer();
  }, 1000);
}

function stopTimer() {
  if (timerId !== null) {
    clearInterval(timerId);
    timerId = null;
  }
}

function updateTimer() {
  timerElement.textContent = formatTime(seconds);
}

function formatTime(totalSeconds) {
  const minutes = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

numberPad.addEventListener("click", event => {
  const button = event.target.closest("button");
  if (!button) return;

  const number = Number(button.dataset.number);
  enterNumber(number);
});

newGameButton.addEventListener("click", newGame);
checkGameButton.addEventListener("click", checkPuzzle);

document.addEventListener("keydown", event => {
  if (event.key >= "1" && event.key <= "9") {
    enterNumber(Number(event.key));
  } else if (event.key === "Backspace" || event.key === "Delete" || event.key === "0") {
    enterNumber(0);
  } else if (event.key === "ArrowUp" && selectedIndex !== null) {
    moveSelection(-1, 0);
  } else if (event.key === "ArrowDown" && selectedIndex !== null) {
    moveSelection(1, 0);
  } else if (event.key === "ArrowLeft" && selectedIndex !== null) {
    moveSelection(0, -1);
  } else if (event.key === "ArrowRight" && selectedIndex !== null) {
    moveSelection(0, 1);
  }
});

function moveSelection(rowDelta, colDelta) {
  let row = Math.floor(selectedIndex / 9);
  let col = selectedIndex % 9;

  row = Math.max(0, Math.min(8, row + rowDelta));
  col = Math.max(0, Math.min(8, col + colDelta));

  selectCell(row * 9 + col);
}

// Start the prototype.
newGame();
